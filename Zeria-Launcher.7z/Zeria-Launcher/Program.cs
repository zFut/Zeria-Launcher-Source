﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace Zeria_Launcher
{
    class Program
    {
        static void Main(string[] args)
        {
            string launcherver = "v0.0.1";
            Console.Title = "zeria lunch eater lol xd funny hahahaha 10/10 comedy gold oscars";
            Console.WriteLine("yello wilcum to zeria lunch er (xddddddddd!!!!!!!!!!!!!! funny!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!) version " + launcherver);
            Console.WriteLine("enter argument to launch app with (leave blank if none)");
            string urmomlol = Console.ReadLine();
            /*Console.WriteLine("argument: " + urmomlol);
            Console.ReadKey();*/

            Process game = new Process();
            game.StartInfo.FileName = @"D:\zeria\Zeria13.exe";
            game.StartInfo.Arguments = urmomlol;
            game.Start();

            Console.WriteLine("Zeria is now launched! You can close this.");

            Console.ReadKey();
        }
    }
}
